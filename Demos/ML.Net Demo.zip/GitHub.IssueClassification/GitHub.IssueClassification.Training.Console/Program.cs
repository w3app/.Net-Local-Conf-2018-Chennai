﻿using Microsoft.ML;
using Microsoft.ML.Data;
using Microsoft.ML.Trainers;
using Microsoft.ML.Transforms;
using System;
using System.Threading.Tasks;

namespace GitHub.IssueClassification.Training.Console
{
    internal static class Program
    {
        private static string DataPath = "C:\\ADotNetConf.22Sep2018\\GitHub.IssueClassification\\GitHub.IssueClassification.Training.Console\\TrainingData\\corefx-issues-train.tsv";

        private static string ModelPath = "C:\\ADotNetConf.22Sep2018\\GitHub.IssueClassification\\GitHub.IssueClassification.Training.Console\\TrainingData\\GitHubLabelerModel.zip";

        private static void Main(string[] args)
        {
            //TrainAsync().Wait();

            Label().Wait();
        }

        private static async Task TrainAsync()
        {
            var pipeline = new LearningPipeline();

            pipeline.Add(new TextLoader(DataPath).CreateFrom<GitHubIssue>(useHeader: true));

            pipeline.Add(new Dictionarizer(("Area", "Label")));

            pipeline.Add(new TextFeaturizer("Title", "Title"));

            pipeline.Add(new TextFeaturizer("Description", "Description"));

            pipeline.Add(new ColumnConcatenator("Features", "Title", "Description"));

            pipeline.Add(new StochasticDualCoordinateAscentClassifier());
            pipeline.Add(new PredictedLabelColumnOriginalValueConverter() { PredictedLabelColumn = "PredictedLabel" });

            System.Console.WriteLine("=============== Training model ===============");

            var model = pipeline.Train<GitHubIssue, GitHubIssuePrediction>();

            await model.WriteAsync(ModelPath);

            System.Console.WriteLine("=============== End training ===============");
            System.Console.WriteLine("The model is saved to {0}", ModelPath);
        }

        private static async Task Label()
        {
            var token = "*****************";
            var repoOwner = "SathishNadarajan";
            var repoName = "demo-project";

            if (string.IsNullOrEmpty(token) ||
                string.IsNullOrEmpty(repoOwner) ||
                string.IsNullOrEmpty(repoName))
            {
                System.Console.Error.WriteLine();
                System.Console.Error.WriteLine("Error: please configure the credentials in the appsettings.json file");
                System.Console.ReadLine();
                return;
            }

            var labeler = new Labeler(repoOwner, repoName, token);

            await labeler.LabelAllNewIssues();

            System.Console.WriteLine("Labeling completed");
            System.Console.ReadLine();
        }
    }
}
